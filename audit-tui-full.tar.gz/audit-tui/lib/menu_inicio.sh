#!/usr/bin/env bash
# Conteúdo completo já descrito
